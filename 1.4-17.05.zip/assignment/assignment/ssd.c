/*
 * ssd.c
 *
 * Created: 15/05/2019 11:20:47 AM
 *  Author: Steve
 */ 

#include <avr/io.h>
#include "score.h"

static volatile uint32_t clockTicks;
uint8_t seven_seg[10] = { 63, 6, 91, 79, 102, 109, 125, 7, 127, 111 };
	
void init_ssd(void) {
	DDRA = 0xFF;
	DDRD = 4;
	PORTA = seven_seg[0];
}

void update_ssd(void) {
	if (get_score() < 10) {
		PORTA = seven_seg[get_score()];	
	} else {
		PORTA = seven_seg[get_score() % 10];
	}
}