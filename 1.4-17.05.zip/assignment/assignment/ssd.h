/*
 * ssd.h
 *
 * Created: 16/05/2019 6:41:13 PM
 *  Author: Steve
 */ 


#ifndef SSD_H_
#define SSD_H_

#include <stdint.h>

void init_ssd(void);
void update_ssd(void);

#endif /* SSD_H_ */