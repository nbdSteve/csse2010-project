/*
 * lives.c
 *
 * Created: 16/05/2019 6:40:53 PM
 *  Author: Steve
 */ 

#include "lives.h"
#include <avr/io.h>

uint32_t remaining_lives;
uint8_t ioboard_led[4] = { 0, 4, 6, 7 };

void init_lives(void) {
	remaining_lives = STARTING_LIVES;
	DDRC = 0xFF;
	PORTC = ioboard_led[remaining_lives];
}

void update_lives(void) {
	PORTC = ioboard_led[remaining_lives];
}

void decrement_lives(uint16_t value) {
	remaining_lives -= value;
	PORTC = ioboard_led[remaining_lives];
}

uint32_t get_remaining_lives(void) {
	return remaining_lives;
}