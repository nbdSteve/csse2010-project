/*
 * ssd.c
 *
 * Created: 15/05/2019 11:20:47 AM
 *  Author: Steve
 */ 

#include <avr/io.h>
#include "score.h"

uint8_t seven_seg[10] = { 63, 6, 91, 79, 102, 109, 125, 7, 127, 111 };
volatile uint8_t digit = 0xFF;
uint8_t initialised = 0;
	
void init_ssd(void) {
	DDRA = 0xFF;
	DDRD = 0xFF;
	initialised = 1;
}

void update_ssd(void) {
	if (initialised == 0) return;
	digit = 0xFF - digit;
	if (get_score() < 10) {
		PORTD = 0;
		PORTA = seven_seg[get_score()];
	} else {
		if (digit == 0) {
			PORTA = seven_seg[get_score() % 10];
		} else {
			PORTA = seven_seg[(get_score() / 10) % 10];
		}
		PORTD = digit;
	}
}