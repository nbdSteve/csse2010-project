/*
 * ssd.c
 *
 * Created: 15/05/2019 11:20:47 AM
 *  Author: Steve
 */ 

#include <avr/io.h>
#include "score.h"

uint8_t seven_seg[10] = { 63, 6, 91, 79, 102, 109, 125, 7, 127, 111 };
	
int init_ssd(void) {
	DDRA = 0xFF;
	DDRD = 1;
	PORTD = seven_seg[1];
	PORTA = seven_seg[0];
}

int update_ssd(void) {
	PORTA = seven_seg[get_score()];
}