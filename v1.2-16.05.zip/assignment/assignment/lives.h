/*
 * lives.h
 *
 * Created: 16/05/2019 6:41:30 PM
 *  Author: Steve
 */ 


#ifndef LIVES_H_
#define LIVES_H_

#include <stdint.h>

void init_lives(void);
void decrement_lives(uint16_t value);
uint32_t get_remaining_lives(void);

#define STARTING_LIVES 4;

#endif /* LIVES_H_ */