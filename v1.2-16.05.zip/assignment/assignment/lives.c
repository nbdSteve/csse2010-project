/*
 * lives.c
 *
 * Created: 16/05/2019 6:40:53 PM
 *  Author: Steve
 */ 

#include "lives.h"

uint32_t remaining_lives;

void init_lives(void) {
	remaining_lives = STARTING_LIVES;
}

void decrement_lives(uint16_t value) {
	remaining_lives -= value;
}

uint32_t get_remaining_lives(void) {
	return remaining_lives;
}