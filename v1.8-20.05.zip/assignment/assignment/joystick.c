/*
 * joystick.c
 *
 * Created: 20/05/2019 12:25:30 PM
 *  Author: Steve
 */ 

#include <avr/io.h>

uint16_t value;
uint8_t x_or_y = 0;

void init_joystick(void) {
	ADMUX = (1<<REFS0);
	ADCSRA = (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1);
}

void read_joystick_input(void) {
	
	if (x_or_y == 0) {
		ADMUX &= ~1;
	} else {
		ADMUX |= 1;
	}
	ADCSRA |= (1<<ADSC);
	
	while(ADCSRA & (1<<ADSC)) {
		; /* Wait until conversion finished */
	}
	value = ADC; // read the value
	if(x_or_y == 0) {
		printf_P("X: %4d ", value);
	} else {
		printf_P("Y: %4d\n", value);
	}
	// Next time through the loop, do the other direction
	x_or_y ^= 1;
	
	/*
	uint8_t input;
	input = PORTD;
	move_cursor(20,10);
	printf_P("Input: %d", input);
	*/
}