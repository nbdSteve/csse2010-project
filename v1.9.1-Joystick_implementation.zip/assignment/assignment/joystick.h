/*
 * joystick.h
 *
 * Created: 23/05/2019 3:48:59 PM
 *  Author: Steve
 */ 


#ifndef JOYSTICK_H_
#define JOYSTICK_H_

void init_joystick(void);
void read_joystick_input(void);


#endif /* JOYSTICK_H_ */