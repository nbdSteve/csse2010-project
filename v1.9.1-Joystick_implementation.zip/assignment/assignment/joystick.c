/*
 * joystick.c
 *
 * Created: 20/05/2019 12:25:30 PM
 *  Author: Steve
 */ 

#include <avr/io.h>

uint16_t value;
uint8_t x_or_y = 0;
volatile uint16_t joystick_x;
volatile uint16_t joystick_y;
static uint8_t initialised = 0;

void init_joystick(void) {
	ADMUX = (1<<REFS0)|(1<<MUX2)|(1<<MUX1);
	ADCSRA = (1<<ADEN)|(1<<ADIE)|(1<<ADPS2)|(1<<ADPS1);
	ADCSRA |= (1<<ADSC);
}

ISR(ADC_vect) {
	value = ADC;
	if (x_or_y == 0) {
		terminal_test();
		joystick_x = value;
	} else {
		terminal_test();
		joystick_y = value;
	}
	
	x_or_y = 1 - x_or_y;
	if (x_or_y == 0) {
		ADMUX &= ~1;
	} else {
		ADMUX |= 1;
	}
	ADCSRA |= (1<<ADSC);
}