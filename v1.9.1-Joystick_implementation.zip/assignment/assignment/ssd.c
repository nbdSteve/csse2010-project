/*
 * ssd.c
 *
 * Created: 15/05/2019 11:20:47 AM
 *  Author: Steve
 */ 

#include <avr/io.h>
#include "score.h"

uint8_t seven_seg[10] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
volatile uint8_t digit = 0x04; // 0b00000100;
static uint8_t initialised = 0;
	
// Initialise the 7 segment display
void init_ssd(void) {
	DDRC = 0xFF;
	//DDRD |= 0b00000100;
	DDRD = 0x04;
	initialised = 1;
}

void update_ssd(void) {
	if (initialised == 0) return;
	//digit = 0b00000100 - digit;
	/*
	digit = 0x04 - digit;
	if (get_score() < 10) {
		PORTD = 0;
		PORTA = seven_seg[get_score()];
	} else {
		if (digit == 0) {
			PORTA = seven_seg[get_score() % 10];
		} else {
			PORTA = seven_seg[(get_score() / 10) % 10];
		}
		PORTD = digit;
	}
	*/
	
	
	// Alternative method for the 7 segment display
	if (get_score() < 10) {
		PORTD = 0x02;
		PORTC = seven_seg[get_score()];
	} else {
		if (digit == 0x04) {
			PORTC = seven_seg[get_score() % 10];
			digit = 0x02;
		} else {
			PORTC = seven_seg[(get_score() / 10) % 10];
			digit = 0x04;
		}
		PORTD = digit;
	}
}